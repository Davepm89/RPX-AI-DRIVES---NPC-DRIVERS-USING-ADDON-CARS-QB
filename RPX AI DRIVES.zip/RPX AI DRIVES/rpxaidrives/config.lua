Config = {}

-- Sections
Config.Sections = {
    City = {
        {npc = "a_m_m_skater_01", vehicle = "police", livery = 0, pos = vector4(216.47, -822.45, 30.55, 71.43)},
        {npc = "a_m_m_skater_01", vehicle = "ambulance", livery = 1, pos = vector4(219.52, -847.21, 30.28, 248.22)}
    },
    Sandy = {
        {npc = "a_m_m_skater_01", vehicle = "sultan", livery = 2, pos = vector4(1800.0, 3600.0, 34.0, 0.0)}
    },
    Paleto = {
        {npc = "a_m_m_skater_01", vehicle = "comet2", livery = 0, pos = vector4(-100.0, 6500.0, 31.0, 180.0)}
    }
}

-- Driving speeds per section
Config.SectionSpeeds = {
    City = 20.0,
    Sandy = 25.0,
    Paleto = 22.0
}
