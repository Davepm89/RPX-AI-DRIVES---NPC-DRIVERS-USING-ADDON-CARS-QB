local npcStates = {}   -- [id] = { id, speed, npcNet, vehNet, data = { npc, vehicle, livery, pos } }
local spawnerSrc = nil

-- Build deterministic IDs from Config on (re)start
CreateThread(function()
    npcStates = {}
    for section, spawns in pairs(Config.Sections) do
        for idx, data in ipairs(spawns) do
            local id = ("%s:%d"):format(section, idx)
            npcStates[id] = {
                id = id,
                speed = Config.SectionSpeeds[section],
                npcNet = nil,
                vehNet = nil,
                data = {
                    npc = data.npc,
                    vehicle = data.vehicle,
                    livery = data.livery or 0,
                    pos = data.pos
                }
            }
        end
    end
end)

local function assignSpawnerIfNeeded(src)
    if not spawnerSrc or not GetPlayerEndpoint(spawnerSrc) then
        spawnerSrc = src
        TriggerClientEvent("rpxaidrives:setSpawner", spawnerSrc, true)

        -- Tell the spawner to create anything not spawned yet
        local toSpawn = {}
        for _, st in pairs(npcStates) do
            if not st.npcNet or not st.vehNet then
                toSpawn[#toSpawn+1] = {
                    id = st.id,
                    npcModel = st.data.npc,
                    vehModel = st.data.vehicle,
                    livery = st.data.livery,
                    pos = st.data.pos,
                    speed = st.speed
                }
            end
        end
        if #toSpawn > 0 then
            TriggerClientEvent("rpxaidrives:spawnBatch", spawnerSrc, toSpawn)
        end
    else
        TriggerClientEvent("rpxaidrives:setSpawner", src, false)
    end
end

-- New player asks for sync
RegisterNetEvent("rpxaidrives:requestSync", function()
    local src = source
    assignSpawnerIfNeeded(src)

    local payload = {}
    for _, st in pairs(npcStates) do
        if st.npcNet and st.vehNet then
            payload[#payload+1] = {
                id = st.id,
                npcNet = st.npcNet,
                vehNet = st.vehNet,
                speed = st.speed,
                npcModel = st.data.npc,
                vehModel = st.data.vehicle
            }
        end
    end
    if #payload > 0 then
        TriggerClientEvent("rpxaidrives:attachBatch", src, payload)
    end
end)

-- Spawner reports a freshly created pair
RegisterNetEvent("rpxaidrives:reportSpawned", function(id, npcNet, vehNet)
    if source ~= spawnerSrc then return end
    local st = npcStates[id]
    if not st then return end
    st.npcNet = npcNet
    st.vehNet = vehNet

    -- Give replication a moment so every client knows these IDs
    SetTimeout(200, function()
        TriggerClientEvent("rpxaidrives:attachOne", -1, {
            id = id,
            npcNet = npcNet,
            vehNet = vehNet,
            speed = st.speed,
            npcModel = st.data.npc,
            vehModel = st.data.vehicle
        })
    end)
end)

-- If spawner leaves, allow reassignment
AddEventHandler("playerDropped", function()
    if tonumber(source) == tonumber(spawnerSrc) then
        spawnerSrc = nil
    end
end)

-- Server cleanup (no network ops here)
AddEventHandler("onResourceStop", function(res)
    if res == GetCurrentResourceName() then
        npcStates = {}
        spawnerSrc = nil
    end
end)
