local isSpawner = false
local spawnedLocal = {}   -- [id] = { npc, veh, npcNet, vehNet }
local attachedLocal = {}  -- [id] = true

local function GetDrivingStyle()
    return 786603 -- normal realistic driving
end

-- Robust model loader (supports custom cars/peds)
local function LoadModel(model)
    local hash = type(model) == "number" and model or GetHashKey(model)
    if not HasModelLoaded(hash) then
        RequestModel(hash)
        local tries = 0
        while not HasModelLoaded(hash) and tries < 200 do
            Wait(50)
            tries = tries + 1
        end
    end
    return HasModelLoaded(hash)
end

-- Wait until a networked entity actually exists on this client
local function WaitForNetEntity(netId, tries, delay)
    tries = tries or 60
    delay = delay or 50
    if not netId or netId == 0 then return nil end
    for i=1,tries do
        if NetworkDoesEntityExistWithNetworkId(netId) then
            local ent = NetToEnt(netId)
            if ent ~= 0 and DoesEntityExist(ent) then
                return ent
            end
        end
        Wait(delay)
    end
    return nil
end

-- Ensure entity is networked and get a net ID (retry)
local function EnsureNetId(ent)
    if not DoesEntityExist(ent) then return nil end
    local tries = 0
    while not NetworkGetEntityIsNetworked(ent) and tries < 40 do
        NetworkRegisterEntityAsNetworked(ent)
        Wait(25)
        tries = tries + 1
    end
    if not NetworkGetEntityIsNetworked(ent) then return nil end

    local netId = NetworkGetNetworkIdFromEntity(ent)
    tries = 0
    while (not netId or netId == 0) and tries < 40 do
        Wait(25)
        netId = NetworkGetNetworkIdFromEntity(ent)
        tries = tries + 1
    end
    return (netId and netId ~= 0) and netId or nil
end

-- Spawner-only: create one NPC + vehicle and report back to server
local function SpawnOne(entry)
    if spawnedLocal[entry.id] then return end
    if not LoadModel(entry.vehModel) or not LoadModel(entry.npcModel) then return end

    local veh = CreateVehicle(GetHashKey(entry.vehModel), entry.pos.x, entry.pos.y, entry.pos.z, entry.pos.w, true, true)
    if not DoesEntityExist(veh) then return end

    SetVehicleLivery(veh, entry.livery or 0)
    SetVehicleOnGroundProperly(veh)
    SetVehicleEngineOn(veh, true, true, true)
    SetVehicleDoorsLocked(veh, 1)
    SetEntityAsMissionEntity(veh, true, true)

    local npc = CreatePedInsideVehicle(veh, 4, GetHashKey(entry.npcModel), -1, true, false)
    if not DoesEntityExist(npc) then
        DeleteVehicle(veh)
        return
    end
    SetPedKeepTask(npc, true)
    SetEntityAsMissionEntity(npc, true, true)
    TaskWarpPedIntoVehicle(npc, veh, -1)

    local vehNet = EnsureNetId(veh)
    local npcNet = EnsureNetId(npc)
    if not vehNet or not npcNet then
        if DoesEntityExist(npc) then DeletePed(npc) end
        if DoesEntityExist(veh) then DeleteVehicle(veh) end
        return
    end

    SetNetworkIdExistsOnAllMachines(vehNet, true)
    SetNetworkIdExistsOnAllMachines(npcNet, true)
    SetNetworkIdCanMigrate(vehNet, true)
    SetNetworkIdCanMigrate(npcNet, true)

    CreateThread(function()
        Wait(400)
        if DoesEntityExist(npc) and DoesEntityExist(veh) then
            TaskVehicleDriveWander(npc, veh, entry.speed, GetDrivingStyle())
        end
    end)

    spawnedLocal[entry.id] = { npc = npc, veh = veh, npcNet = npcNet, vehNet = vehNet }
    attachedLocal[entry.id] = true

    TriggerServerEvent("rpxaidrives:reportSpawned", entry.id, npcNet, vehNet)
end

-- Non-spawner: attach tasks to existing entities from net IDs
local function AttachOne(info)
    if attachedLocal[info.id] then return end
    if not info.npcNet or not info.vehNet then return end

    LoadModel(info.vehModel); LoadModel(info.npcModel)

    local npc = WaitForNetEntity(info.npcNet, 80, 50)
    local veh = WaitForNetEntity(info.vehNet, 80, 50)
    if not npc or not veh then
        -- try again once after 1s
        CreateThread(function()
            Wait(1000)
            if not attachedLocal[info.id] then
                local npc2 = WaitForNetEntity(info.npcNet, 60, 50)
                local veh2 = WaitForNetEntity(info.vehNet, 60, 50)
                if npc2 and veh2 then
                    TaskVehicleDriveWander(npc2, veh2, info.speed, GetDrivingStyle())
                    attachedLocal[info.id] = true
                end
            end
        end)
        return
    end

    TaskVehicleDriveWander(npc, veh, info.speed, GetDrivingStyle())
    attachedLocal[info.id] = true
end

-- ===== Events =====
RegisterNetEvent("rpxaidrives:setSpawner", function(state)
    isSpawner = state and true or false
end)

RegisterNetEvent("rpxaidrives:spawnBatch", function(list)
    if not isSpawner then return end
    for _, entry in ipairs(list) do
        SpawnOne(entry)
        Wait(75)
    end
end)

RegisterNetEvent("rpxaidrives:attachBatch", function(list)
    for _, info in ipairs(list) do
        if info.npcNet and info.vehNet then
            AttachOne(info)
        end
        Wait(25)
    end
end)

RegisterNetEvent("rpxaidrives:attachOne", function(info)
    if info.npcNet and info.vehNet then
        AttachOne(info)
    end
end)

-- On client load, ask server for sync (and possibly become spawner)
CreateThread(function()
    Wait(1200)
    TriggerServerEvent("rpxaidrives:requestSync")
end)

-- Client cleanup: only delete what this client created
AddEventHandler("onResourceStop", function(res)
    if res ~= GetCurrentResourceName() then return end
    for id, ent in pairs(spawnedLocal) do
        if DoesEntityExist(ent.npc) then DeletePed(ent.npc) end
        if DoesEntityExist(ent.veh) then DeleteVehicle(ent.veh) end
        spawnedLocal[id] = nil
    end
    attachedLocal = {}
end)
