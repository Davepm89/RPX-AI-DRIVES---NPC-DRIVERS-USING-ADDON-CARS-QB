fx_version 'cerulean'
game 'gta5'

author 'RPX (Roleplay Xclusive)'
description 'RPX AI Drives - NPCs driving in custom vehicles'
version '1.0.0'
lua54 'yes'

-- These files stay editable for server owners
escrow_ignore {
    'config.lua',     
    'client.lua',     
    'server.lua'     
}

-- Shared config
shared_script 'config.lua'

-- Client scripts
client_scripts {
    'client.lua'
}

-- Server scripts
server_scripts {
    'server.lua'
}
