RPX AI Drives

Bring your city to life with AI-driven NPCs in custom vehicles.

🚀 What is RPX AI Drives?

RPX AI Drives is a FiveM resource that spawns NPCs in your city and lets them drive around naturally in both default GTA vehicles and your own custom addon cars.

This adds immersion and makes your world feel alive — NPCs aren’t just standing around, they’re actually driving through your roleplay environment.

⚙️ Installation

Drag the folder rpxaidrives into your resources directory.

Add this to your server.cfg:

ensure rpxaidrives


Configure your NPCs and vehicles inside config.lua.

Choose ped models

Add GTA or custom vehicle names

Set spawn positions with heading

Adjust speeds per area (City, Sandy, Paleto, etc)

That’s it — restart your server and enjoy a more immersive city!

🌟 Benefits of Using RPX AI Drives

Immersive Roleplay: Your city feels alive with NPCs driving around.

Supports Custom Vehicles: NPCs can use addon cars, making your server unique.

Optimized & Synced: Fully networked so all players see the same vehicles/NPCs.

No Duplication: Safe cleanup prevents multiple NPCs spawning on restart.

Configurable: Control which NPCs spawn, where they appear, and how fast they drive.

Plug & Play: Simple setup, works with QBCore or standalone servers.

📞 Support & Community

💬 Join the RPX (Roleplay Xclusive) Discord: discord.gg/uQCTvBmKKM

🛒 Get it on Tebex: rpx.tebex.io